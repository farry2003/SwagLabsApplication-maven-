package TestCases;


import java.io.IOException;

import java.util.*;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import PageObjects.CartPage;
import PageObjects.CompletionPage;
import PageObjects.HomePage;
import PageObjects.InfoPage;
import PageObjects.LoginPage;
import PageObjects.OverviewPage;
import TestBase.BaseTest;
import Utils.ExcelUtils;


public class test001 extends BaseTest {
	
	@Test(priority = 1)
	public void validating_Title_And_URL() {
	    test = extent.createTest("Validating Title and URL");

	    LoginPage lp = new LoginPage(driver);
	    String title = lp.getTitle();
	    String URL = lp.getURL();

	    try {
	        Assert.assertEquals(title, "Swag Labs");
	        test.pass("Title matched: " + title);
	    } catch (Exception e) {
	        test.fail("Title mismatch: Expected 'Swag Labs' but got '" + title + "'");
	       System.out.println(e.getMessage());
	    }

	    try {
	        Assert.assertEquals(URL, p.getProperty("appURL"));
	        test.pass("URL matched: " + URL);
	    } catch (Exception e) {
	        test.fail("URL mismatch: Expected '" + p.getProperty("appURL") + "' but got '" + URL + "'");
		       System.out.println(e.getMessage());
	    }
	}
	@Test(priority = 2)
	public void DDT() throws IOException {
		test = extent.createTest("Validating Credentials");
		LoginPage lp = null;
		String username = null;
		 List<Map<String, String>> loginData = ExcelUtils.getLoginData("Sheet1");
		   

		    for (Map<String, String> user : loginData) {
		    	try {
		        username = user.get("Username");
		        String password = user.get("Password");

		         lp = new LoginPage(driver);
		        lp.enterUsername(username);
		        lp.enterPassword(password);
		       lp.clickLogin();

		        HomePage hp = new HomePage(driver);
		        boolean actualResult = hp.isLoginSuccessful();

		        if (actualResult) {
		        	System.out.println(" Login successful for: " + username);
		         test.pass(" Login successful for: " + username);
		        } else {
		        	System.out.println(" Login failed for: " + username);
		            test.fail(" Login failed for: " + username);
		        }
		        driver.navigate().to("https://www.saucedemo.com");
		    }catch(Exception e) {
		    	lp.cleanUp();
		    	System.out.println(" Login failed for: " + username);
		    	test.fail("Invalid credentials "+ username);
		    }
		    }
		   
		}
	@Test(priority = 3)
	public void validatingZ_A_Order() {
	    test = extent.createTest("Validating Z_A_Order");

	    try {
	        // Login
	        LoginPage lp = new LoginPage(driver);
	        lp.enterUsername(p.getProperty("username"));
	        lp.enterPassword(p.getProperty("password"));
	        lp.clickLogin();

	        // Select Z to A order
	        HomePage hp = new HomePage(driver);
	        hp.selectZ_A();

	        List<WebElement> actualData = hp.checkDescOrder(); // This should return product name elements in Z-A order

	        	        List<String> expectedData = Arrays.asList(
	            "Test.allTheThings() T-Shirt (Red)",
	            "Sauce Labs Onesie",
	            "Sauce Labs Fleece Jacket",
	            "Sauce Labs Bolt T-Shirt",
	            "Sauce Labs Bike Light",
	            "Sauce Labs Backpack"
	        );

	        for (int i = 0; i < actualData.size(); i++) {
	            String actualText = actualData.get(i).getText().trim();
	            String expectedText = expectedData.get(i).trim();

	            System.out.println("Comparing: " + actualText + " = " + expectedText);
	            Assert.assertEquals(actualText, expectedText, " Mismatch at index " + i);
	        }
	        test.pass(" Products are in Z-A order");
	        hp.selectProduct();
	       if(hp.CheckingaddedToCart()) {
	        	test.pass("Added to cart Successfully");
	       }else {
	        	test.fail("Added to cart Failed");
	        	Assert.fail();
	       }
	    } catch (Exception e) {
	        test.fail("Products not in Z-A order: " + e.getMessage());
	        Assert.fail("Test failed due to exception: " + e.getMessage());
	    }
	}
	@Test(priority = 4)
	 public void validatingMessage() {
		 test = extent.createTest("Validating Message");

		    try {
		        // Login
		        LoginPage lp = new LoginPage(driver);
		        lp.enterUsername(p.getProperty("username"));
		        lp.enterPassword(p.getProperty("password"));
		        lp.clickLogin();
		        HomePage hp = new HomePage(driver);
		        hp.selectZ_A();
		        hp.selectProduct();
		        hp.clickOnCart();
		        CartPage cp = new CartPage(driver);
		        cp.clickCheckOut();
		        InfoPage ip = new InfoPage(driver);
		        ip.addFirstName(p.getProperty("firstName"));
		        ip.addLastName(p.getProperty("lastName"));
		        ip.addPostalCode(p.getProperty("postalCode"));
		        ip.clickContinue();
		        OverviewPage op = new OverviewPage(driver);
		        op.clickFinish();
		        CompletionPage comp = new CompletionPage(driver);
		        if(comp.checkConfirmation()) {
		        	test.pass("Order Is Completed");
		        }else {
		        	test.fail("Order Is Not Completed");
		        	Assert.fail();
		        }
		        
	}catch(Exception e) {
		Assert.fail();
		test.info(e.getMessage());
	}

	
		
	}
}




