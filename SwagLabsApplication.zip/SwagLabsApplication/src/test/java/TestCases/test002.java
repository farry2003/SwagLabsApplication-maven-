package TestCases;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import PageObjects.HomePage;
import PageObjects.LoginPage;
import TestBase.BaseTest;

public class test002 extends BaseTest {
	@Test
	public void printOnConsole() {
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername(p.getProperty("username"));
		lp.enterPassword(p.getProperty("password"));
		lp.clickLogin();
		HomePage hp = new HomePage(driver);
		List<WebElement> allLinks = hp.getList();
		for (WebElement a : allLinks) {
			System.out.println(a.getText().trim());
		}
	}
}
