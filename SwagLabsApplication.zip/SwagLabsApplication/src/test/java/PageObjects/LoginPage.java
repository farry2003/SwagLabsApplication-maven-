package PageObjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import TestBase.BasePage;

public class LoginPage extends BasePage {

	public LoginPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(xpath = "//div[@class='login_logo']")WebElement title_para;
	@FindBy(id = "user-name")WebElement username_text;
	@FindBy(id = "password")WebElement password_text;
	@FindBy(id = "login-button")WebElement login_btn;
	@FindBy(xpath = "//h3[text()='Epic sadface: Sorry, this user has been locked out.']")WebElement error_text;
	

	//*[@id="login_button_container"]/div/form/div[3]/h3/text()
	
	public  String getTitle() {
		return title_para.getText();
	}
	public String getURL() {
		return driver.getCurrentUrl();
	}
	public void enterUsername(String username) {
		username_text.sendKeys(username);
	}
	public void enterPassword(String password) {
		password_text.sendKeys(password);
	}
	public void clickLogin() {
		login_btn.click();
	}
	public boolean checkForInvalid() {
		return error_text.isDisplayed();
	}
	
	
	public void cleanUp() {
		username_text.click();
		    Actions act = new Actions(driver);
		    act.keyDown(Keys.CONTROL)
		       .sendKeys(Keys.BACK_SPACE)
		       .keyUp(Keys.CONTROL)
		       .build()
		       .perform();
		    password_text.click();
		    act.keyDown(Keys.CONTROL)
		       .sendKeys(Keys.BACK_SPACE)
		       .keyUp(Keys.CONTROL)
		       .build()
		       .perform();
		    
	}
}
