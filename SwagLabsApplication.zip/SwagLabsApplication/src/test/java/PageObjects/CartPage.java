package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import TestBase.BasePage;

public class CartPage extends BasePage {

	public CartPage(WebDriver driver) {
		super(driver);
		}
	
	@FindBy(id = "checkout")WebElement checkout_btn;
	
	public void clickCheckOut() {
		checkout_btn.click();
	}

}
