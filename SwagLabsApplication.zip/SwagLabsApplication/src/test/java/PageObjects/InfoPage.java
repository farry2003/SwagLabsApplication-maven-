package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import TestBase.BasePage;
import TestBase.BaseTest;

public class InfoPage extends BasePage{

	public InfoPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(id = "first-name")WebElement firstName_text;
	@FindBy(id = "last-name")WebElement lastName_text;
	@FindBy(id = "postal-code")WebElement postalCode_text;
	@FindBy(id = "continue")WebElement continue_btn;
	
	
	public void addFirstName(String firstname) {
		firstName_text.sendKeys(firstname);
	}
	
	public void addLastName(String lastname) {
		lastName_text.sendKeys(lastname);
	}
	
	public void addPostalCode(String postalCode ) {
		postalCode_text.sendKeys(postalCode);
	}
	
	public void clickContinue() {
		continue_btn.click();
	}
	
	
}
