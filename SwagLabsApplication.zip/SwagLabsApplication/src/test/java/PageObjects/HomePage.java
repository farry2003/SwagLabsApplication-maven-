package PageObjects;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import TestBase.BasePage;

public class HomePage extends BasePage {

	public HomePage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/span")
	WebElement title_homepage;
	@FindBy(xpath = "//*[@id=\"header_container\"]/div[2]/div/span/select")
	WebElement select_text;
	@FindBy(id = "add-to-cart-test.allthethings()-t-shirt-(red)")
	WebElement addtocart_btn;
	@FindBy(xpath = "//span[@class='shopping_cart_badge']")
	WebElement span_btn;
	@FindBy(className = "shopping_cart_link")
	WebElement cart_link;

	public boolean isLoginSuccessful() {
		return title_homepage.isDisplayed();
	}

	public List<WebElement> checkDescOrder() {
		List<WebElement> actualData = driver.findElements(By.xpath("//a[contains(@id, 'title_link')]"));
		return actualData;
	}

	public void selectProduct() {
		addtocart_btn.click();
	}

	public boolean CheckingaddedToCart() {
		return span_btn.isDisplayed();
	}
	
	public List<WebElement> getList(){
		List<WebElement>links = driver.findElements(By.tagName("a"));
		return links;
	}
	
	public void clickOnCart() {
		cart_link.click();
	}

	public void selectZ_A() {
		Select sel = new Select(select_text);
		sel.selectByValue("za");
	}
}
