package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import TestBase.BasePage;

public class OverviewPage extends BasePage {

	public OverviewPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(id = "finish")
	WebElement finish_btn;
	
	public void clickFinish() {
		finish_btn.click();
	}

}
