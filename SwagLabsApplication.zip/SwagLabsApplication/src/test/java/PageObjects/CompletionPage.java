package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import TestBase.BasePage;

public class CompletionPage extends BasePage {

	public CompletionPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//h2[text()='Thank you for your order!']")
	WebElement complete_txt;
	
	public boolean checkConfirmation() {
		return complete_txt.isDisplayed();
	}
}
