package Utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
    public static List<Map<String, String>> getLoginData(String sheetName) throws IOException {
        List<Map<String, String>> dataList = new ArrayList<>();
        FileInputStream fis = new FileInputStream("./src/test/resources/TestData/LoginData.xlsx");
        XSSFWorkbook wb = new XSSFWorkbook(fis);
        Sheet sheet = wb.getSheet(sheetName);

        Row header = sheet.getRow(0);
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            Map<String, String> data = new HashMap<>();
            for (int j = 0; j < header.getLastCellNum(); j++) {
                data.put(header.getCell(j).getStringCellValue(), row.getCell(j).getStringCellValue());
            }
            dataList.add(data);
        }
        wb.close();
        return dataList;
    }
}

